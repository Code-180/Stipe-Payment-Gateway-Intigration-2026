# PayFlow — Stripe Payment Gateway

A production-ready payment processing demo built with **Node.js**, **Express**, and **Stripe**. Features a premium dark-themed fintech UI with glassmorphism design, complete payment lifecycle management, and real-time transaction tracking.

![Node.js](https://img.shields.io/badge/Node.js-18+-green) ![Stripe](https://img.shields.io/badge/Stripe-Payment%20Intents-blue) ![License](https://img.shields.io/badge/License-MIT-yellow)

## ✨ Features

- 💳 **Payment Processing** — Stripe Payment Intents with Payment Element
- 📊 **Transaction Dashboard** — Real-time stats, filtering, and pagination
- 💰 **Refund Management** — Full and partial refunds with modal UI
- 🔄 **Retry Mechanism** — Retry failed payments seamlessly
- 🎨 **Premium UI** — Dark theme with glassmorphism, gradients, and micro-animations
- 🔒 **Secure** — Helmet.js, CORS, webhook signature verification
- 📱 **Responsive** — Mobile-first responsive design

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- A [Stripe account](https://dashboard.stripe.com/register) (free)

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
Edit the `.env` file with your Stripe test keys:
```env
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
```

Get your keys from the [Stripe Dashboard](https://dashboard.stripe.com/test/apikeys).

### 3. Start the Server
```bash
# Development (with auto-reload)
npm run dev

# Production
npm start
```

### 4. Open in Browser
Navigate to [http://localhost:4242](http://localhost:4242)

## 🧪 Test Cards

| Card Number | Scenario |
|---|---|
| `4242 4242 4242 4242` | Successful payment |
| `4000 0000 0000 9995` | Payment declined |
| `4000 0025 0000 3155` | Requires 3D Secure |
| `4000 0000 0000 0077` | Charge succeeds, refund fails |

Use any future expiry date and any 3-digit CVC.

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/payments/config` | Get Stripe publishable key |
| `POST` | `/api/payments/create-intent` | Create payment intent |
| `GET` | `/api/payments/history` | List payments (paginated) |
| `GET` | `/api/payments/:id` | Get payment details |
| `POST` | `/api/payments/:id/refund` | Refund a payment |
| `POST` | `/api/payments/:id/retry` | Retry failed payment |
| `POST` | `/api/webhooks/stripe` | Stripe webhook handler |

## 🏗️ Project Structure

```
├── server/                 # Backend (Express)
│   ├── index.js           # Server entry point
│   ├── config/stripe.js   # Stripe SDK initialization
│   ├── controllers/       # Business logic
│   ├── routes/            # API route definitions
│   ├── middleware/         # Validation & error handling
│   └── utils/             # Logger & in-memory store
├── public/                 # Frontend (SPA)
│   ├── index.html         # HTML shell
│   ├── css/               # Design system
│   └── js/                # Application modules
├── .env                   # Environment configuration
└── package.json
```

## 📄 License

MIT
