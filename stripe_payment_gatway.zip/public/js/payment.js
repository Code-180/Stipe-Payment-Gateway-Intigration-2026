/**
 * Payment Form Module
 * 
 * Handles amount selection, form display, and redirecting the user
 * to Stripe's hosted Checkout page for secure payment processing.
 * No credit card fields are collected on this platform.
 */

const PaymentForm = {
  selectedAmount: 2500,

  /**
   * Initialize the payment form
   */
  async init() {
    try {
      // Fetch publishable key to validate Stripe is configured
      const config = await API.getConfig();
      
      if (!config.publishableKey || config.publishableKey.includes('REPLACE')) {
        document.getElementById('stripe-redirect-info').innerHTML = `
          <div style="padding: 24px; text-align: center; color: var(--warning);">
            <p style="font-size: 0.95rem; font-weight: 600; margin-bottom: 8px;">⚠ Stripe Not Configured</p>
            <p style="font-size: 0.85rem; color: var(--text-muted);">
              Please add your Stripe test keys to the <code>.env</code> file.<br>
              Get keys from <a href="https://dashboard.stripe.com/test/apikeys" target="_blank" style="color: var(--accent);">Stripe Dashboard</a>
            </p>
          </div>
        `;
        document.getElementById('submit-payment').disabled = true;
        return;
      }

      this.setupAmountSelection();

      // Check if returning from Stripe with a session_id
      this.checkReturnFromStripe();
    } catch (error) {
      console.error('Payment init error:', error);
      document.getElementById('stripe-redirect-info').innerHTML = `
        <div style="padding: 24px; text-align: center; color: var(--danger);">
          <p style="font-size: 0.95rem; font-weight: 600; margin-bottom: 8px;">Connection Error</p>
          <p style="font-size: 0.85rem; color: var(--text-muted);">${error.message}</p>
        </div>
      `;
      document.getElementById('submit-payment').disabled = true;
    }
  },

  /**
   * Check if the user is returning from Stripe Checkout
   */
  async checkReturnFromStripe() {
    const hash = window.location.hash;
    
    // Handle success return with session_id
    if (hash.includes('session_id=')) {
      const sessionId = hash.split('session_id=')[1]?.split('&')[0];
      if (sessionId) {
        await this.verifyPayment(sessionId);
      }
    }

    // Handle cancel return
    if (hash.includes('reason=cancelled')) {
      this.showFailure('Payment was cancelled. You were not charged.');
      // Clean up the URL
      window.location.hash = '#/failure';
    }
  },

  /**
   * Verify a completed payment session
   * @param {string} sessionId 
   */
  async verifyPayment(sessionId) {
    try {
      Utils.setLoading(true, 'Verifying your payment...');
      
      const result = await API.verifySession(sessionId);
      
      Utils.setLoading(false);

      if (result.paymentStatus === 'paid' || result.status === 'succeeded') {
        this.showSuccess(result);
      } else {
        this.showFailure(`Payment status: ${result.paymentStatus || result.status}. Please try again.`);
      }
    } catch (error) {
      Utils.setLoading(false);
      console.error('Verification error:', error);
      this.showFailure(`Could not verify payment: ${error.message}`);
    }
  },

  /**
   * Set up amount preset buttons and custom amount input
   */
  setupAmountSelection() {
    // Preset buttons
    document.querySelectorAll('.amount-preset').forEach(btn => {
      btn.addEventListener('click', () => {
        const amount = parseInt(btn.dataset.amount);
        this.setAmount(amount);
        
        // Update active state
        document.querySelectorAll('.amount-preset').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Clear custom input
        document.getElementById('custom-amount').value = '';
      });
    });

    // Custom amount input
    const customInput = document.getElementById('custom-amount');
    customInput.addEventListener('input', () => {
      const value = parseFloat(customInput.value);
      if (value && value >= 0.5) {
        const cents = Math.round(value * 100);
        this.setAmount(cents);
        
        // Remove preset active states
        document.querySelectorAll('.amount-preset').forEach(b => b.classList.remove('active'));
      }
    });

    // Submit button — redirects to Stripe
    document.getElementById('submit-payment').addEventListener('click', () => this.submit());
  },

  /**
   * Update the selected amount and refresh the display
   * @param {number} amountInCents 
   */
  setAmount(amountInCents) {
    this.selectedAmount = amountInCents;
    const formatted = Utils.formatAmount(amountInCents);
    document.getElementById('display-amount').textContent = formatted;
    document.getElementById('btn-text').textContent = `Pay ${formatted} with Stripe`;
  },

  /**
   * Handle form submission — create Checkout Session and redirect to Stripe
   */
  async submit() {
    const submitBtn = document.getElementById('submit-payment');
    const btnText = document.getElementById('btn-text');
    const btnSpinner = document.getElementById('btn-spinner');

    // Show loading state
    submitBtn.disabled = true;
    btnText.classList.add('hidden');
    btnSpinner.classList.remove('hidden');

    try {
      const description = document.getElementById('payment-description')?.value || '';
      const customerEmail = document.getElementById('customer-email')?.value || '';

      // Create Checkout Session on the server
      const result = await API.createCheckoutSession({
        amount: this.selectedAmount,
        currency: 'usd',
        description,
        customerEmail,
      });

      // Redirect to Stripe's hosted checkout page
      if (result.checkoutUrl) {
        Utils.toast('Redirecting to Stripe...', 'info');
        window.location.href = result.checkoutUrl;
      } else {
        throw new Error('No checkout URL returned from server');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      Utils.toast(`Failed to start checkout: ${error.message}`, 'error');
      
      submitBtn.disabled = false;
      btnText.classList.remove('hidden');
      btnSpinner.classList.add('hidden');
    }
  },

  /**
   * Display success screen with transaction details
   * @param {Object} sessionData 
   */
  showSuccess(sessionData) {
    const details = document.getElementById('success-details');
    const now = new Date().toISOString();
    
    details.innerHTML = `
      <div class="result-detail-row">
        <span class="result-detail-label">Session ID</span>
        <span class="result-detail-value mono">${sessionData.sessionId || 'N/A'}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Payment ID</span>
        <span class="result-detail-value mono">${sessionData.paymentIntentId || 'N/A'}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Amount</span>
        <span class="result-detail-value">${Utils.formatAmount(sessionData.amount, sessionData.currency)}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Status</span>
        <span class="result-detail-value">${Utils.statusBadge(sessionData.status)}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Email</span>
        <span class="result-detail-value">${sessionData.customerEmail || 'N/A'}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Date</span>
        <span class="result-detail-value">${Utils.formatDate(now)}</span>
      </div>
      <div class="result-detail-row">
        <span class="result-detail-label">Refund Window</span>
        <span class="result-detail-value">${Utils.calculateReturnDate(now)}</span>
      </div>
    `;

    window.app.showView('success');
    Utils.toast('Payment verified successfully!', 'success');
  },

  /**
   * Display failure screen
   * @param {string} message 
   */
  showFailure(message) {
    document.getElementById('failure-message').textContent = 
      message || 'An error occurred while processing your payment. Please try again.';
    window.app.showView('failure');
    Utils.toast('Payment was not completed.', 'error');
  },

  /**
   * Reset the payment form to initial state
   */
  async reset() {
    this.selectedAmount = 2500;
    
    document.querySelectorAll('.amount-preset').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.amount === '2500');
    });
    document.getElementById('custom-amount').value = '';
    document.getElementById('payment-description').value = '';
    const emailInput = document.getElementById('customer-email');
    if (emailInput) emailInput.value = '';
    this.setAmount(2500);
  },
};

// Make globally available
window.payment = PaymentForm;
