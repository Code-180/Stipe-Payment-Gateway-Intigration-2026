/**
 * Shared Utilities
 * 
 * Common helper functions used across the frontend application.
 * Includes formatting, date calculations, badge generation, and toasts.
 */

const Utils = {
  /**
   * Format amount from cents to display string
   * @param {number} amount - Amount in cents
   * @param {string} currency - Currency code
   * @returns {string}
   */
  formatAmount(amount, currency = 'usd') {
    const value = amount / 100;
    const symbols = { usd: '$', eur: '€', gbp: '£', inr: '₹', cad: 'CA$', aud: 'A$', jpy: '¥' };
    const symbol = symbols[currency.toLowerCase()] || '$';
    
    if (currency.toLowerCase() === 'jpy') {
      return `${symbol}${Math.round(value).toLocaleString()}`;
    }
    return `${symbol}${value.toFixed(2)}`;
  },

  /**
   * Format a date string for display
   * @param {string} dateStr - ISO date string
   * @returns {string}
   */
  formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  },

  /**
   * Format date as short string
   * @param {string} dateStr - ISO date string
   * @returns {string}
   */
  formatDateShort(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
    });
  },

  /**
   * Calculate return/refund window date (7 days from payment)
   * @param {string} dateStr - Payment date
   * @returns {string}
   */
  calculateReturnDate(dateStr) {
    const date = new Date(dateStr);
    date.setDate(date.getDate() + 7);
    return date.toLocaleDateString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    });
  },

  /**
   * Generate status badge HTML
   * @param {string} status - Payment status
   * @returns {string}
   */
  statusBadge(status) {
    const labels = {
      succeeded: 'Succeeded',
      failed: 'Failed',
      pending: 'Pending',
      processing: 'Processing',
      requires_payment_method: 'Awaiting Payment',
      requires_confirmation: 'Needs Confirmation',
      requires_action: 'Action Required',
      refunded: 'Refunded',
      partially_refunded: 'Partial Refund',
      retried: 'Retried',
      canceled: 'Canceled',
      expired: 'Expired',
      paid: 'Paid',
      unpaid: 'Unpaid',
    };
    const label = labels[status] || status;
    return `<span class="badge badge-${status}">${label}</span>`;
  },

  /**
   * Truncate a string (for payment intent IDs)
   * @param {string} str - Input string
   * @param {number} len - Max length
   * @returns {string}
   */
  truncate(str, len = 20) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
  },

  /**
   * Show toast notification
   * @param {string} message - Toast message
   * @param {'success'|'error'|'info'|'warning'} type - Toast type
   * @param {number} duration - Auto-dismiss duration in ms
   */
  toast(message, type = 'info', duration = 4000) {
    const container = document.getElementById('toast-container');
    const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' };
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${icons[type]}</span>
      <span class="toast-message">${message}</span>
      <button class="toast-close" onclick="this.parentElement.remove()">✕</button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('removing');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },

  /**
   * Show/hide loading overlay
   * @param {boolean} show 
   * @param {string} message 
   */
  setLoading(show, message = 'Processing...') {
    const overlay = document.getElementById('loading-overlay');
    const msg = document.getElementById('loading-message');
    msg.textContent = message;
    
    if (show) {
      overlay.classList.add('active');
    } else {
      overlay.classList.remove('active');
    }
  },

  /**
   * Time ago from date string
   * @param {string} dateStr 
   * @returns {string}
   */
  timeAgo(dateStr) {
    const now = new Date();
    const date = new Date(dateStr);
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  },
};

// Make globally available
window.Utils = Utils;
