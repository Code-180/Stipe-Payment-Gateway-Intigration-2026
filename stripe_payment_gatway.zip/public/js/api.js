/**
 * API Client Module
 * 
 * Fetch-based HTTP client for communicating with the backend API.
 * All methods return parsed JSON responses with error handling.
 */

const API = {
  baseUrl: '/api',

  /**
   * Generic fetch wrapper with error handling
   */
  async request(endpoint, options = {}) {
    try {
      const url = `${this.baseUrl}${endpoint}`;
      const config = {
        headers: { 'Content-Type': 'application/json' },
        ...options,
      };

      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.details?.join(', ') || `Request failed with status ${response.status}`);
      }

      return data;
    } catch (error) {
      if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
        throw new Error('Unable to connect to the server. Please check if the server is running.');
      }
      throw error;
    }
  },

  /**
   * Get Stripe publishable key from the server
   * @returns {Promise<{publishableKey: string}>}
   */
  async getConfig() {
    const result = await this.request('/payments/config');
    return result.data;
  },

  /**
   * Create a Stripe Checkout Session and get the redirect URL
   * @param {Object} params - { amount, currency, description, customerEmail }
   * @returns {Promise<Object>} - { sessionId, checkoutUrl, amount, currency }
   */
  async createCheckoutSession({ amount, currency = 'usd', description = '', customerEmail = '' }) {
    const result = await this.request('/payments/create-checkout-session', {
      method: 'POST',
      body: JSON.stringify({ amount, currency, description, customerEmail }),
    });
    return result.data;
  },

  /**
   * Verify a Checkout Session after returning from Stripe
   * @param {string} sessionId - Stripe Checkout Session ID
   * @returns {Promise<Object>}
   */
  async verifySession(sessionId) {
    const result = await this.request(`/payments/verify-session/${sessionId}`);
    return result.data;
  },

  /**
   * Fetch payment history
   * @param {Object} params - { page, limit, status }
   * @returns {Promise<Object>}
   */
  async getPayments({ page = 1, limit = 10, status = '' } = {}) {
    const params = new URLSearchParams({ page, limit });
    if (status) params.set('status', status);
    
    const result = await this.request(`/payments/history?${params}`);
    return result.data;
  },

  /**
   * Get a single payment by ID
   * @param {string} id - Payment / Session ID
   * @returns {Promise<Object>}
   */
  async getPayment(id) {
    const result = await this.request(`/payments/${id}`);
    return result.data;
  },

  /**
   * Process a refund
   * @param {string} id - Payment ID
   * @param {number|null} amount - Refund amount in cents (null for full refund)
   * @returns {Promise<Object>}
   */
  async refundPayment(id, amount = null) {
    const body = {};
    if (amount !== null) body.amount = amount;
    
    const result = await this.request(`/payments/${id}/refund`, {
      method: 'POST',
      body: JSON.stringify(body),
    });
    return result.data;
  },

  /**
   * Retry a failed payment
   * @param {string} id - Original Payment ID
   * @returns {Promise<Object>}
   */
  async retryPayment(id) {
    const result = await this.request(`/payments/${id}/retry`, {
      method: 'POST',
    });
    return result.data;
  },
};

// Make globally available
window.API = API;
