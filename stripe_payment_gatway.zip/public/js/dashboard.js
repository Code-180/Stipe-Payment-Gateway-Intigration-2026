/**
 * Transaction Dashboard Module
 * 
 * Manages the dashboard view including stats display, transaction
 * table rendering, detail view, and filtering.
 */

const Dashboard = {
  currentPage: 1,
  currentFilter: '',

  /**
   * Load dashboard data from API
   */
  async load() {
    try {
      const data = await API.getPayments({
        page: this.currentPage,
        limit: 10,
        status: this.currentFilter,
      });

      this.renderStats(data.stats);
      this.renderTransactions(data.payments, data.total, data.totalPages);
    } catch (error) {
      console.error('Dashboard load error:', error);
      document.getElementById('transactions-container').innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">⚠️</div>
          <h3>Unable to Load Transactions</h3>
          <p>${error.message}</p>
          <button class="btn btn-outline" onclick="window.dashboard.load()">Try Again</button>
        </div>
      `;
    }
  },

  /**
   * Render statistics cards
   * @param {Object} stats 
   */
  renderStats(stats) {
    if (!stats) return;
    document.getElementById('stat-total').textContent = stats.totalPayments;
    document.getElementById('stat-amount').textContent = Utils.formatAmount(stats.totalAmount);
    document.getElementById('stat-pending').textContent = stats.pendingPayments;
    document.getElementById('stat-refunded').textContent = Utils.formatAmount(stats.totalRefunded);
    document.getElementById('stat-success-rate').textContent = `${stats.successRate}% success rate`;
  },

  /**
   * Render the transactions table
   * @param {Array} payments 
   * @param {number} total 
   * @param {number} totalPages 
   */
  renderTransactions(payments, total, totalPages) {
    const container = document.getElementById('transactions-container');

    if (!payments || payments.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <h3>No Transactions Yet</h3>
          <p>Make your first payment to see it appear here.</p>
          <button class="btn btn-primary" onclick="window.app.navigate('pay')">Make a Payment</button>
        </div>
      `;
      return;
    }

    let tableHTML = `
      <div class="table-container">
        <table class="transaction-table">
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
    `;

    payments.forEach(payment => {
      const canRefund = payment.status === 'succeeded' || payment.status === 'partially_refunded';
      const canRetry = payment.status === 'failed';

      tableHTML += `
        <tr>
          <td><span class="tx-id" title="${payment.id}">${payment.id}</span></td>
          <td><span class="tx-amount">${Utils.formatAmount(payment.amount, payment.currency)}</span></td>
          <td>${Utils.statusBadge(payment.status)}</td>
          <td><span class="tx-date">${Utils.formatDate(payment.createdAt)}</span></td>
          <td>
            <div class="tx-actions">
              <button class="btn btn-outline btn-sm" onclick="window.dashboard.viewDetail('${payment.id}')">View</button>
              ${canRefund ? `<button class="btn btn-danger btn-sm" onclick="window.dashboard.initiateRefund('${payment.id}')">Refund</button>` : ''}
              ${canRetry ? `<button class="btn btn-outline btn-sm" onclick="window.dashboard.retryPayment('${payment.id}')">Retry</button>` : ''}
            </div>
          </td>
        </tr>
      `;
    });

    tableHTML += `</tbody></table></div>`;

    // Pagination
    if (totalPages > 1) {
      tableHTML += `<div class="flex items-center justify-between mt-lg" style="flex-wrap:wrap;gap:8px;">`;
      tableHTML += `<span class="text-muted" style="font-size:0.85rem;">Showing ${payments.length} of ${total} transactions</span>`;
      tableHTML += `<div class="flex gap-sm">`;
      
      if (this.currentPage > 1) {
        tableHTML += `<button class="btn btn-outline btn-sm" onclick="window.dashboard.goToPage(${this.currentPage - 1})">← Previous</button>`;
      }
      if (this.currentPage < totalPages) {
        tableHTML += `<button class="btn btn-outline btn-sm" onclick="window.dashboard.goToPage(${this.currentPage + 1})">Next →</button>`;
      }
      
      tableHTML += `</div></div>`;
    }

    container.innerHTML = tableHTML;
  },

  /**
   * Navigate to a specific page
   * @param {number} page 
   */
  goToPage(page) {
    this.currentPage = page;
    this.load();
  },

  /**
   * View transaction detail
   * @param {string} id - Payment Intent ID
   */
  async viewDetail(id) {
    try {
      Utils.setLoading(true, 'Loading transaction details...');
      const payment = await API.getPayment(id);
      Utils.setLoading(false);
      
      this.renderDetail(payment);
      window.app.showView('detail');
    } catch (error) {
      Utils.setLoading(false);
      Utils.toast(`Failed to load transaction: ${error.message}`, 'error');
    }
  },

  /**
   * Render transaction detail view
   * @param {Object} payment 
   */
  renderDetail(payment) {
    const container = document.getElementById('detail-content');
    const data = payment.stripeData || payment;
    
    let html = `
      <button class="tx-detail-back" onclick="window.app.navigate('dashboard')">
        ← Back to Dashboard
      </button>
      
      <div class="page-header" style="text-align:left;margin-bottom:32px;">
        <h1 style="font-size:1.5rem;">Transaction Details</h1>
        <p>Payment ID: <span style="font-family:var(--font-mono);font-size:0.85rem;">${payment.id}</span></p>
      </div>

      <div class="detail-grid">
        <div class="glass-card">
          <div class="card-body">
            <div class="detail-section">
              <h3>Payment Information</h3>
              <div class="detail-row">
                <span class="detail-label">Amount</span>
                <span class="detail-value">${Utils.formatAmount(payment.amount, payment.currency)}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Currency</span>
                <span class="detail-value">${(payment.currency || 'usd').toUpperCase()}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value">${Utils.statusBadge(payment.status)}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Description</span>
                <span class="detail-value">${payment.description || 'N/A'}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Created</span>
                <span class="detail-value">${Utils.formatDate(payment.createdAt)}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Last Updated</span>
                <span class="detail-value">${Utils.formatDate(payment.updatedAt)}</span>
              </div>
              <div class="detail-row">
                <span class="detail-label">Refund Window</span>
                <span class="detail-value">${Utils.calculateReturnDate(payment.createdAt)}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="glass-card">
          <div class="card-body">
            <div class="detail-section">
              <h3>Refund History</h3>
    `;

    if (payment.refunds && payment.refunds.length > 0) {
      html += `
              <div class="detail-row">
                <span class="detail-label">Total Refunded</span>
                <span class="detail-value text-danger">${Utils.formatAmount(payment.totalRefunded, payment.currency)}</span>
              </div>
              <ul class="refund-list mt-md">
      `;
      payment.refunds.forEach(r => {
        html += `
                <li class="refund-item">
                  <div>
                    <span class="refund-item-amount">${Utils.formatAmount(r.amount, payment.currency)}</span>
                    <span class="refund-item-date">${Utils.formatDate(r.createdAt)}</span>
                  </div>
                  <span class="badge badge-${r.status === 'succeeded' ? 'succeeded' : 'pending'}">${r.status}</span>
                </li>
        `;
      });
      html += `</ul>`;
    } else {
      html += `<p class="text-muted" style="font-size:0.9rem;">No refunds have been processed for this transaction.</p>`;
    }

    html += `
            </div>

            <div class="detail-section mt-lg">
              <h3>Actions</h3>
              <div class="flex gap-sm" style="flex-wrap:wrap;">
    `;

    if (payment.status === 'succeeded' || payment.status === 'partially_refunded') {
      html += `<button class="btn btn-danger btn-sm" onclick="window.dashboard.initiateRefund('${payment.id}')">Process Refund</button>`;
    }
    if (payment.status === 'failed') {
      html += `<button class="btn btn-primary btn-sm" onclick="window.dashboard.retryPayment('${payment.id}')">Retry Payment</button>`;
    }
    
    html += `
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = html;
  },

  /**
   * Initiate refund for a payment
   * @param {string} id 
   */
  async initiateRefund(id) {
    try {
      const paymentData = await API.getPayment(id);
      RefundManager.openModal(paymentData);
    } catch (error) {
      Utils.toast(`Failed to load payment data: ${error.message}`, 'error');
    }
  },

  /**
   * Retry a failed payment
   * @param {string} id 
   */
  async retryPayment(id) {
    try {
      Utils.setLoading(true, 'Creating new payment attempt...');
      const result = await API.retryPayment(id);
      Utils.setLoading(false);
      
      // Redirect to Stripe Checkout
      if (result.checkoutUrl) {
        Utils.toast('Redirecting to Stripe checkout...', 'info');
        window.location.href = result.checkoutUrl;
      } else {
        Utils.toast('Retry created but no checkout URL was returned.', 'warning');
        this.load();
      }
    } catch (error) {
      Utils.setLoading(false);
      Utils.toast(`Retry failed: ${error.message}`, 'error');
    }
  },

  /**
   * Initialize filter listener
   */
  initFilters() {
    const filterSelect = document.getElementById('status-filter');
    if (filterSelect) {
      filterSelect.addEventListener('change', () => {
        this.currentFilter = filterSelect.value;
        this.currentPage = 1;
        this.load();
      });
    }
  },
};

// Make globally available
window.dashboard = Dashboard;
