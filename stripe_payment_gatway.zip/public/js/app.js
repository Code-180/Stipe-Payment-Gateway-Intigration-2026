/**
 * SPA Application Router & Initialization
 * 
 * Manages view switching, navigation state, and application bootstrap.
 * Uses hash-based routing for simplicity (#/pay, #/dashboard, etc).
 */

const App = {
  currentView: 'pay',
  initialized: false,

  /**
   * Initialize the application
   */
  async init() {
    if (this.initialized) return;
    this.initialized = true;

    console.log('%c PayFlow — Stripe Payment Gateway ', 
      'background: linear-gradient(135deg, #6366f1, #a855f7); color: white; font-size: 14px; padding: 8px 16px; border-radius: 6px;');

    // Set up navigation
    this.setupNavigation();

    // Handle hash-based routing
    this.handleRoute();
    window.addEventListener('hashchange', () => this.handleRoute());

    // Initialize payment module
    await window.payment.init();

    // Initialize dashboard filters
    window.dashboard.initFilters();

    console.log('✓ Application initialized');
  },

  /**
   * Set up navigation click handlers
   */
  setupNavigation() {
    // Nav link clicks
    document.querySelectorAll('.nav-link[data-view]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const view = link.dataset.view;
        this.navigate(view);
      });
    });

    // Mobile menu toggle
    const toggle = document.getElementById('nav-toggle');
    const links = document.getElementById('nav-links');
    if (toggle) {
      toggle.addEventListener('click', () => {
        links.classList.toggle('open');
      });
    }

    // Close mobile menu on link click
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        links.classList.remove('open');
      });
    });
  },

  /**
   * Navigate to a view
   * @param {string} view - View name (pay, dashboard, detail, success, failure)
   */
  navigate(view) {
    window.location.hash = `/${view}`;
  },

  /**
   * Handle route changes
   */
  handleRoute() {
    const hash = window.location.hash.replace('#/', '') || 'pay';
    const view = hash.split('/')[0] || 'pay';
    
    this.showView(view);

    // Load data when navigating to dashboard
    if (view === 'dashboard') {
      window.dashboard.load();
    }

    // Reset payment form when navigating to pay
    if (view === 'pay' && this.currentView !== 'pay') {
      // Don't reset on initial load
      if (this.currentView) {
        window.payment.reset();
      }
    }
  },

  /**
   * Show a specific view section and update nav state
   * @param {string} viewName 
   */
  showView(viewName) {
    this.currentView = viewName;

    // Hide all view sections
    document.querySelectorAll('.view-section').forEach(section => {
      section.classList.remove('active');
    });

    // Show the target view
    const targetView = document.getElementById(`view-${viewName}`);
    if (targetView) {
      targetView.classList.add('active');
    }

    // Update nav active state (only for main nav views)
    document.querySelectorAll('.nav-link[data-view]').forEach(link => {
      link.classList.remove('active');
      if (link.dataset.view === viewName) {
        link.classList.add('active');
      }
    });

    // For non-nav views (success, failure, detail), keep the parent nav active
    if (['success', 'failure'].includes(viewName)) {
      document.querySelector('[data-view="pay"]')?.classList.add('active');
    }
    if (viewName === 'detail') {
      document.querySelector('[data-view="dashboard"]')?.classList.add('active');
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
};

// Make globally available
window.app = App;

// Bootstrap the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
