/**
 * Refund Management Module
 * 
 * Handles the refund modal, refund type selection (full/partial),
 * amount validation, and refund processing.
 */

const RefundManager = {
  currentPayment: null,
  refundType: 'full',

  /**
   * Open refund modal for a specific payment
   * @param {Object} payment - Payment record
   */
  openModal(payment) {
    this.currentPayment = payment;
    this.refundType = 'full';
    
    const maxRefundable = payment.amount - payment.totalRefunded;
    const modal = document.getElementById('refund-modal');
    const body = document.getElementById('refund-modal-body');
    
    body.innerHTML = `
      <div class="refund-amount-info">
        <strong>Original Amount:</strong> ${Utils.formatAmount(payment.amount, payment.currency)}<br>
        <strong>Already Refunded:</strong> ${Utils.formatAmount(payment.totalRefunded, payment.currency)}<br>
        <strong>Max Refundable:</strong> ${Utils.formatAmount(maxRefundable, payment.currency)}
      </div>
      
      <div class="refund-type-selector">
        <button class="refund-type-btn active" id="refund-full-btn" onclick="window.refund.setType('full')">
          Full Refund<br><small style="font-weight:400;color:var(--text-muted)">${Utils.formatAmount(maxRefundable, payment.currency)}</small>
        </button>
        <button class="refund-type-btn" id="refund-partial-btn" onclick="window.refund.setType('partial')">
          Partial Refund<br><small style="font-weight:400;color:var(--text-muted)">Custom amount</small>
        </button>
      </div>
      
      <div id="partial-amount-container" class="hidden">
        <div class="form-group">
          <label for="refund-amount-input">Refund Amount (in dollars)</label>
          <input type="number" class="form-input" id="refund-amount-input" 
                 placeholder="Enter amount" min="0.01" max="${(maxRefundable / 100).toFixed(2)}" step="0.01">
        </div>
      </div>
    `;
    
    modal.classList.add('active');
  },

  /**
   * Close refund modal
   */
  closeModal() {
    document.getElementById('refund-modal').classList.remove('active');
    this.currentPayment = null;
  },

  /**
   * Set refund type (full or partial)
   * @param {'full'|'partial'} type 
   */
  setType(type) {
    this.refundType = type;
    
    const fullBtn = document.getElementById('refund-full-btn');
    const partialBtn = document.getElementById('refund-partial-btn');
    const partialContainer = document.getElementById('partial-amount-container');
    
    if (type === 'full') {
      fullBtn.classList.add('active');
      partialBtn.classList.remove('active');
      partialContainer.classList.add('hidden');
    } else {
      fullBtn.classList.remove('active');
      partialBtn.classList.add('active');
      partialContainer.classList.remove('hidden');
      document.getElementById('refund-amount-input')?.focus();
    }
  },

  /**
   * Confirm and process the refund
   */
  async confirm() {
    if (!this.currentPayment) return;
    
    const payment = this.currentPayment;
    let refundAmount = null;
    
    if (this.refundType === 'partial') {
      const input = document.getElementById('refund-amount-input');
      const dollarAmount = parseFloat(input?.value);
      
      if (!dollarAmount || isNaN(dollarAmount) || dollarAmount <= 0) {
        Utils.toast('Please enter a valid refund amount', 'error');
        return;
      }
      
      refundAmount = Math.round(dollarAmount * 100);
      const maxRefundable = payment.amount - payment.totalRefunded;
      
      if (refundAmount > maxRefundable) {
        Utils.toast(`Maximum refundable amount is ${Utils.formatAmount(maxRefundable, payment.currency)}`, 'error');
        return;
      }
    }
    
    const confirmBtn = document.getElementById('confirm-refund-btn');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<div class="spinner"></div> Processing...';
    
    try {
      const result = await API.refundPayment(payment.id, refundAmount);
      
      this.closeModal();
      Utils.toast(
        `Refund of ${Utils.formatAmount(result.amount, result.currency)} processed successfully!`,
        'success'
      );
      
      // Refresh dashboard if active
      if (document.getElementById('view-dashboard').classList.contains('active')) {
        window.dashboard.load();
      }
    } catch (error) {
      Utils.toast(`Refund failed: ${error.message}`, 'error');
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = 'Process Refund';
    }
  },
};

// Make globally available
window.refund = RefundManager;
