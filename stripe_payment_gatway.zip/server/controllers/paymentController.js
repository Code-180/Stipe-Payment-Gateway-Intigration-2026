/**
 * Payment Controller
 * 
 * Business logic for payment operations including creating Stripe Checkout
 * Sessions (redirect to Stripe), verifying sessions after return,
 * fetching payment history, processing refunds, and retrying failed payments.
 */

const stripe = require('../config/stripe');
const store = require('../utils/store');
const logger = require('../utils/logger');

/**
 * Create a new Stripe Checkout Session and return the URL to redirect to
 * POST /api/payments/create-checkout-session
 */
async function createCheckoutSession(req, res, next) {
  try {
    const {
      amount,
      currency = 'usd',
      description = '',
      customerEmail = ''
    } = req.body;

    logger.info(`Creating Checkout Session: ${amount} ${currency.toUpperCase()}`);

    const sessionParams = {
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: currency.toLowerCase(),
          product_data: {
            name: description || `Payment of ${(amount / 100).toFixed(2)} ${currency.toUpperCase()}`,
            description: 'Secure payment via PayFlow',
          },
          unit_amount: amount,
        },
        quantity: 1,
      }, ],
      success_url: `${process.env.CLIENT_URL || 'http://localhost:4242'}#/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL || 'http://localhost:4242'}#/failure?reason=cancelled`,
      metadata: {
        source: 'stripe-payment-gateway-demo',
        customerEmail,
        description,
      },
    };

    // Add customer email if provided
    if (customerEmail) {
      sessionParams.customer_email = customerEmail;
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    // Store the payment record locally (linked by session ID)
    store.add(session.id, {
      amount,
      currency: currency.toLowerCase(),
      description,
      customerEmail,
      status: 'pending',
      type: 'checkout_session',
      metadata: sessionParams.metadata,
    });

    logger.success(`Checkout Session created: ${session.id}`);

    res.status(201).json({
      success: true,
      data: {
        sessionId: session.id,
        checkoutUrl: session.url,
        amount,
        currency: currency.toLowerCase(),
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Verify a Checkout Session after the user returns from Stripe
 * GET /api/payments/verify-session/:sessionId
 */
async function verifySession(req, res, next) {
  try {
    const {
      sessionId
    } = req.params;

    logger.info(`Verifying Checkout Session: ${sessionId}`);

    // Retrieve the session from Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ['payment_intent', 'line_items'],
    });

    // Update local store with session result
    const paymentData = {
      status: session.payment_status === 'paid' ? 'succeeded' : session.payment_status,
      stripePaymentIntentId: session.payment_intent?.id || null,
      amountTotal: session.amount_total,
      customerEmail: session.customer_details?.email || session.customer_email || '',
    };

    store.update(sessionId, paymentData);

    // Also store by payment intent ID if available (for refund/webhook lookups)
    if (session.payment_intent?.id) {
      const existing = store.get(sessionId);
      if (existing && !store.get(session.payment_intent.id)) {
        store.add(session.payment_intent.id, {
          ...existing,
          ...paymentData,
          id: session.payment_intent.id,
          checkoutSessionId: sessionId,
        });
      }
    }

    logger.success(`Session verified: ${sessionId} — Status: ${session.payment_status}`);

    res.json({
      success: true,
      data: {
        sessionId: session.id,
        paymentIntentId: session.payment_intent?.id || null,
        paymentStatus: session.payment_status,
        status: paymentData.status,
        amount: session.amount_total,
        currency: session.currency,
        customerEmail: session.customer_details?.email || session.customer_email || '',
        description: session.metadata?.description || '',
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get payment history with pagination and filtering
 * GET /api/payments/history
 */
async function getPaymentHistory(req, res, next) {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const status = req.query.status || '';

    const result = store.getAll({
      page,
      limit,
      status
    });
    const stats = store.getStats();

    res.json({
      success: true,
      data: {
        ...result,
        stats,
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get a single payment by ID with fresh Stripe data
 * GET /api/payments/:id
 */
async function getPaymentById(req, res, next) {
  try {
    const {
      id
    } = req.params;

    // Get local record
    let payment = store.get(id);
    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }

    // Try to fetch latest status from Stripe
    try {
      // Check if this is a checkout session ID or payment intent ID
      let stripeData;
      if (id.startsWith('cs_')) {
        const session = await stripe.checkout.sessions.retrieve(id, {
          expand: ['payment_intent'],
        });
        stripeData = {
          status: session.payment_status === 'paid' ? 'succeeded' : session.payment_status,
          paymentMethod: session.payment_intent?.payment_method || null,
          created: session.created,
          amount: session.amount_total,
          amountReceived: session.amount_total,
          currency: session.currency,
          description: session.metadata?.description || '',
        };
      } else if (id.startsWith('pi_')) {
        const paymentIntent = await stripe.paymentIntents.retrieve(id);
        stripeData = {
          status: paymentIntent.status,
          paymentMethod: paymentIntent.payment_method,
          created: paymentIntent.created,
          amount: paymentIntent.amount,
          amountReceived: paymentIntent.amount_received,
          currency: paymentIntent.currency,
          description: paymentIntent.description,
        };
      }

      if (stripeData) {
        payment = store.update(id, {
          status: stripeData.status
        });

        res.json({
          success: true,
          data: {
            ...payment,
            stripeData,
          },
        });
        return;
      }
    } catch (stripeError) {
      logger.warn(`Could not fetch Stripe data for ${id}: ${stripeError.message}`);
    }

    // Return local data if Stripe fetch fails
    res.json({
      success: true,
      data: payment,
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Process a refund (full or partial)
 * POST /api/payments/:id/refund
 */
async function refundPayment(req, res, next) {
  try {
    const {
      id
    } = req.params;
    const {
      amount
    } = req.body; // Optional: omit for full refund

    const payment = store.get(id);
    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }

    // Resolve the payment intent ID for refund
    let paymentIntentId = id;
    if (id.startsWith('cs_')) {
      // Lookup the payment intent ID from the stored record
      if (payment.stripePaymentIntentId) {
        paymentIntentId = payment.stripePaymentIntentId;
      } else {
        // Fetch from Stripe
        const session = await stripe.checkout.sessions.retrieve(id);
        paymentIntentId = session.payment_intent;
        store.update(id, {
          stripePaymentIntentId: paymentIntentId
        });
      }
    }

    if (!paymentIntentId || !paymentIntentId.startsWith('pi_')) {
      return res.status(400).json({
        success: false,
        error: 'Cannot process refund: payment has not been completed',
      });
    }

    // Validate refund amount
    const maxRefundable = payment.amount - payment.totalRefunded;
    if (maxRefundable <= 0) {
      return res.status(400).json({
        success: false,
        error: 'This payment has already been fully refunded',
      });
    }

    if (amount && amount > maxRefundable) {
      return res.status(400).json({
        success: false,
        error: `Maximum refundable amount is ${maxRefundable} (${(maxRefundable / 100).toFixed(2)} ${payment.currency.toUpperCase()})`,
      });
    }

    logger.info(`Processing refund for ${paymentIntentId}: ${amount ? `partial (${amount})` : 'full'}`);

    // Create Stripe refund
    const refundParams = {
      payment_intent: paymentIntentId,
    };
    if (amount) {
      refundParams.amount = amount;
    }

    const refund = await stripe.refunds.create(refundParams);

    // Update local store
    store.addRefund(id, {
      id: refund.id,
      amount: refund.amount,
      status: refund.status,
    });

    logger.success(`Refund processed: ${refund.id} (${refund.amount} ${refund.currency})`);

    res.json({
      success: true,
      data: {
        refundId: refund.id,
        amount: refund.amount,
        currency: refund.currency,
        status: refund.status,
        payment: store.get(id),
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Retry a failed payment by creating a new Checkout Session
 * POST /api/payments/:id/retry
 */
async function retryPayment(req, res, next) {
  try {
    const {
      id
    } = req.params;

    const payment = store.get(id);
    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }

    if (payment.status === 'succeeded') {
      return res.status(400).json({
        success: false,
        error: 'This payment has already succeeded. No retry needed',
      });
    }

    logger.info(`Retrying payment: ${id} (amount: ${payment.amount})`);

    // Create a new Checkout Session with the same parameters
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: payment.currency,
          product_data: {
            name: `Retry: ${payment.description || 'Payment'}`,
            description: 'Secure payment via PayFlow',
          },
          unit_amount: payment.amount,
        },
        quantity: 1,
      }, ],
      success_url: `${process.env.CLIENT_URL || 'http://localhost:4242'}#/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL || 'http://localhost:4242'}#/failure?reason=cancelled`,
      metadata: {
        source: 'stripe-payment-gateway-demo',
        retryOf: id,
        customerEmail: payment.customerEmail || '',
        description: `Retry: ${payment.description}`,
      },
    });

    // Store the new payment
    store.add(session.id, {
      amount: payment.amount,
      currency: payment.currency,
      description: `Retry: ${payment.description}`,
      customerEmail: payment.customerEmail,
      status: 'pending',
      type: 'checkout_session',
      metadata: {
        retryOf: id,
      },
    });

    // Mark original as retried
    store.update(id, {
      status: 'retried'
    });

    logger.success(`Retry session created: ${session.id} (replaces ${id})`);

    res.status(201).json({
      success: true,
      data: {
        sessionId: session.id,
        checkoutUrl: session.url,
        originalPaymentId: id,
        amount: payment.amount,
        currency: payment.currency,
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get publishable key for frontend
 * GET /api/payments/config
 */
function getConfig(req, res) {
  res.json({
    success: true,
    data: {
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
    },
  });
}

module.exports = {
  createCheckoutSession,
  verifySession,
  getPaymentHistory,
  getPaymentById,
  refundPayment,
  retryPayment,
  getConfig,
};