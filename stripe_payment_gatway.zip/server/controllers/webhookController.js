/**
 * Webhook Controller
 * 
 * Processes incoming Stripe webhook events to keep the local payment
 * store in sync with Stripe's authoritative state. Verifies webhook
 * signatures to prevent spoofing. Handles checkout.session.completed
 * events for the redirect-based Checkout flow.
 */

const stripe = require('../config/stripe');
const store = require('../utils/store');
const logger = require('../utils/logger');

/**
 * Handle incoming Stripe webhook events
 * POST /api/webhooks/stripe
 */
async function handleStripeWebhook(req, res) {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;

  try {
    if (webhookSecret && webhookSecret !== 'whsec_REPLACE_WITH_YOUR_WEBHOOK_SECRET') {
      // Verify webhook signature (production)
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } else {
      // Skip signature verification in development
      event = JSON.parse(req.body.toString());
      logger.warn('Webhook signature verification skipped (no webhook secret configured)');
    }
  } catch (err) {
    logger.error(`Webhook signature verification failed: ${err.message}`);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  logger.info(`Webhook received: ${event.type}`, { id: event.id });

  // Process the event
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        logger.success(`💰 Checkout session completed: ${session.id}`);
        
        store.update(session.id, {
          status: session.payment_status === 'paid' ? 'succeeded' : session.payment_status,
          stripePaymentIntentId: session.payment_intent,
          amountTotal: session.amount_total,
          customerEmail: session.customer_details?.email || '',
        });

        // Also store/update by payment intent ID
        if (session.payment_intent) {
          const existing = store.get(session.id);
          if (existing && !store.get(session.payment_intent)) {
            store.add(session.payment_intent, {
              ...existing,
              id: session.payment_intent,
              checkoutSessionId: session.id,
              status: session.payment_status === 'paid' ? 'succeeded' : session.payment_status,
            });
          } else if (store.get(session.payment_intent)) {
            store.update(session.payment_intent, {
              status: session.payment_status === 'paid' ? 'succeeded' : session.payment_status,
            });
          }
        }
        break;
      }

      case 'checkout.session.expired': {
        const session = event.data.object;
        logger.warn(`⏰ Checkout session expired: ${session.id}`);
        
        store.update(session.id, {
          status: 'expired',
        });
        break;
      }

      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object;
        logger.success(`💰 Payment succeeded: ${paymentIntent.id}`);
        
        store.update(paymentIntent.id, {
          status: 'succeeded',
          amountReceived: paymentIntent.amount_received,
        });
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object;
        const error = paymentIntent.last_payment_error;
        logger.error(`❌ Payment failed: ${paymentIntent.id}`, {
          code: error?.code,
          message: error?.message,
        });
        
        store.update(paymentIntent.id, {
          status: 'failed',
          errorMessage: error?.message || 'Payment failed',
          errorCode: error?.code,
        });
        break;
      }

      case 'payment_intent.processing': {
        const paymentIntent = event.data.object;
        logger.info(`⏳ Payment processing: ${paymentIntent.id}`);
        
        store.update(paymentIntent.id, {
          status: 'processing',
        });
        break;
      }

      case 'charge.refunded': {
        const charge = event.data.object;
        logger.info(`💸 Charge refunded: ${charge.id}`, {
          paymentIntent: charge.payment_intent,
          amountRefunded: charge.amount_refunded,
        });
        break;
      }

      case 'charge.refund.updated': {
        const refund = event.data.object;
        logger.info(`🔄 Refund updated: ${refund.id}`, {
          status: refund.status,
        });
        break;
      }

      default:
        logger.debug(`Unhandled event type: ${event.type}`);
    }
  } catch (error) {
    logger.error(`Error processing webhook event ${event.type}: ${error.message}`);
  }

  // Always return 200 to acknowledge receipt
  res.json({ received: true });
}

module.exports = {
  handleStripeWebhook,
};
