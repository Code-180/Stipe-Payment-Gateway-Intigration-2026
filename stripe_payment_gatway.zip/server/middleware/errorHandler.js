/**
 * Global Error Handler Middleware
 * 
 * Catches all unhandled errors and returns consistent JSON error responses.
 * Handles Stripe-specific errors with appropriate status codes and messages.
 */

const logger = require('../utils/logger');

function errorHandler(err, req, res, _next) {
  logger.error(`${req.method} ${req.originalUrl}`, {
    message: err.message,
    type: err.type,
    code: err.code,
  });

  // Stripe-specific errors
  if (err.type && err.type.startsWith('Stripe')) {
    return handleStripeError(err, res);
  }

  // Generic application errors
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && {
      stack: err.stack
    }),
  });
}

/**
 * Parse Stripe errors into user-friendly responses
 */
function handleStripeError(err, res) {
  let statusCode = 500;
  let message = 'An unexpected payment error occurred';

  switch (err.type) {
    case 'StripeCardError':
      // Card was declined
      statusCode = 402;
      message = err.message || 'Your card was declined';
      break;

    case 'StripeRateLimitError':
      statusCode = 429;
      message = 'Too many requests. Please try again in a moment';
      break;

    case 'StripeInvalidRequestError':
      statusCode = 400;
      message = err.message || 'Invalid payment request';
      break;

    case 'StripeAPIError':
      statusCode = 502;
      message = 'Payment service temporarily unavailable';
      break;

    case 'StripeConnectionError':
      statusCode = 503;
      message = 'Unable to connect to payment service';
      break;

    case 'StripeAuthenticationError':
      statusCode = 500;
      message = 'Payment configuration error. Contact support';
      logger.error('Stripe authentication failed — check API keys!');
      break;

    default:
      statusCode = 500;
      message = 'An unexpected payment error occurred';
  }

  res.status(statusCode).json({
    success: false,
    error: message,
    code: err.code || 'unknown',
    declineCode: err.decline_code || null,
  });
}

module.exports = errorHandler;