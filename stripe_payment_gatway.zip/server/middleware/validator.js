/**
 * Request Validation Middleware
 * 
 * Validates incoming request data for payment and refund operations.
 * Returns 400 errors with descriptive messages for invalid input.
 */

const SUPPORTED_CURRENCIES = ['usd', 'eur', 'gbp', 'inr', 'cad', 'aud', 'jpy'];
const MIN_AMOUNT = 50; // Stripe minimum: 50 cents (USD)
const MAX_AMOUNT = 99999999; // $999,999.99

/**
 * Validate payment creation request
 */
function validatePaymentCreation(req, res, next) {
  const {
    amount,
    currency,
    description
  } = req.body;
  const errors = [];

  // Amount validation
  if (amount === undefined || amount === null) {
    errors.push('Amount is required');
  } else if (typeof amount !== 'number' || !Number.isInteger(amount)) {
    errors.push('Amount must be an integer (in smallest currency unit, e.g., cents)');
  } else if (amount < MIN_AMOUNT) {
    errors.push(`Amount must be at least ${MIN_AMOUNT} (${MIN_AMOUNT / 100} in currency units)`);
  } else if (amount > MAX_AMOUNT) {
    errors.push(`Amount cannot exceed ${MAX_AMOUNT}`);
  }

  // Currency validation
  if (currency && !SUPPORTED_CURRENCIES.includes(currency.toLowerCase())) {
    errors.push(`Unsupported currency. Supported: ${SUPPORTED_CURRENCIES.join(', ')}`);
  }

  // Description validation (optional, but sanitize)
  if (description && typeof description !== 'string') {
    errors.push('Description must be a string');
  }
  if (description && description.length > 500) {
    errors.push('Description cannot exceed 500 characters');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors,
    });
  }

  next();
}

/**
 * Validate refund request
 */
function validateRefund(req, res, next) {
  const {
    amount
  } = req.body;

  if (amount !== undefined) {
    if (typeof amount !== 'number' || !Number.isInteger(amount)) {
      return res.status(400).json({
        success: false,
        error: 'Refund amount must be an integer (in smallest currency unit)',
      });
    }
    if (amount < 1) {
      return res.status(400).json({
        success: false,
        error: 'Refund amount must be at least 1',
      });
    }
  }

  next();
}

module.exports = {
  validatePaymentCreation,
  validateRefund,
};