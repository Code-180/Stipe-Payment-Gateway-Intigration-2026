/**
 * Payment Routes
 * 
 * Defines all payment-related API endpoints with validation middleware.
 * Uses Stripe Checkout Sessions for redirect-based payment flow.
 */

const express = require('express');
const router = express.Router();
const {
  validatePaymentCreation,
  validateRefund
} = require('../middleware/validator');
const {
  createCheckoutSession,
  verifySession,
  getPaymentHistory,
  getPaymentById,
  refundPayment,
  retryPayment,
  getConfig,
} = require('../controllers/paymentController');

// Get Stripe publishable key for frontend
router.get('/config', getConfig);

// Create a new Checkout Session (redirects user to Stripe)
router.post('/create-checkout-session', validatePaymentCreation, createCheckoutSession);

// Verify a completed Checkout Session
router.get('/verify-session/:sessionId', verifySession);

// Get payment history (paginated)
router.get('/history', getPaymentHistory);

// Get a single payment by ID
router.get('/:id', getPaymentById);

// Refund a payment (full or partial)
router.post('/:id/refund', validateRefund, refundPayment);

// Retry a failed payment
router.post('/:id/retry', retryPayment);

module.exports = router;