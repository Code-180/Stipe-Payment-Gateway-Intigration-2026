/**
 * Webhook Routes
 * 
 * Defines the Stripe webhook endpoint. Uses express.raw() middleware
 * for signature verification (Stripe requires the raw request body).
 */

const express = require('express');
const router = express.Router();
const {
  handleStripeWebhook
} = require('../controllers/webhookController');

// Stripe webhook — must use raw body for signature verification
router.post(
  '/stripe',
  express.raw({
    type: 'application/json'
  }),
  handleStripeWebhook
);

module.exports = router;