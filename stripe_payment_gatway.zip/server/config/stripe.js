/**
 * Stripe SDK Configuration
 * 
 * Initializes the Stripe Node.js SDK with the secret key from environment
 * variables. API version is locked for consistent behavior.
 */

const Stripe = require('stripe');

if (!process.env.STRIPE_SECRET_KEY) {
  console.error('❌ STRIPE_SECRET_KEY is not set in .env file');
  process.exit(1);
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-12-18.acacia',
  appInfo: {
    name: 'Stripe Payment Gateway Demo',
    version: '1.0.0',
  },
});

module.exports = stripe;
