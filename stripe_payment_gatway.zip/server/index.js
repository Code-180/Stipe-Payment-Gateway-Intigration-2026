/**
 * Express Server Entry Point
 * 
 * Sets up the Express application with middleware, routes, static file
 * serving, and error handling. Serves the frontend SPA from /public.
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const logger = require('./utils/logger');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 4242;

// ============================================================
// Middleware
// ============================================================

// Security headers (relaxed CSP — no Stripe.js needed, payments happen on Stripe's page)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        frameSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        connectSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
      },
    },
  })
);

// CORS
app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Request logging
app.use(morgan('dev'));

// ============================================================
// Routes — Webhooks MUST be before JSON body parser
// ============================================================
const webhookRoutes = require('./routes/webhooks');
app.use('/api/webhooks', webhookRoutes);

// JSON body parser (after webhook routes to preserve raw body)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Payment routes
const paymentRoutes = require('./routes/payments');
app.use('/api/payments', paymentRoutes);

// ============================================================
// Static files — Serve frontend SPA
// ============================================================
app.use(express.static(path.join(__dirname, '..', 'public')));

// SPA fallback — serve index.html for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
  }
});

// ============================================================
// Error handling
// ============================================================
app.use(errorHandler);

// ============================================================
// Start server
// ============================================================
app.listen(PORT, () => {
  logger.success(`🚀 Server running on http://localhost:${PORT}`);
  logger.info(`📁 Frontend served from /public`);
  logger.info(`🔑 Stripe mode: ${process.env.STRIPE_SECRET_KEY?.startsWith('sk_live') ? 'LIVE' : 'TEST'}`);
  logger.info(`📋 API endpoints:`);
  logger.info(`   POST /api/payments/create-checkout-session`);
  logger.info(`   GET  /api/payments/verify-session/:sessionId`);
  logger.info(`   GET  /api/payments/history`);
  logger.info(`   GET  /api/payments/:id`);
  logger.info(`   POST /api/payments/:id/refund`);
  logger.info(`   POST /api/payments/:id/retry`);
  logger.info(`   POST /api/webhooks/stripe`);
  logger.info(`   GET  /api/payments/config`);
});

module.exports = app;
