/**
 * Logger Utility
 * 
 * Provides structured, color-coded console logging with timestamps.
 * Supports info, warn, error, success, and debug log levels.
 */

const LOG_LEVELS = {
  INFO: { label: 'INFO', color: '\x1b[36m' },      // Cyan
  WARN: { label: 'WARN', color: '\x1b[33m' },      // Yellow
  ERROR: { label: 'ERROR', color: '\x1b[31m' },     // Red
  SUCCESS: { label: 'SUCCESS', color: '\x1b[32m' }, // Green
  DEBUG: { label: 'DEBUG', color: '\x1b[35m' },     // Magenta
};

const RESET = '\x1b[0m';

/**
 * Format a log message with timestamp and level
 */
function formatMessage(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const { label, color } = LOG_LEVELS[level];
  
  let output = `${color}[${timestamp}] [${label}]${RESET} ${message}`;
  
  if (data) {
    output += `\n${color}  └─${RESET} ${JSON.stringify(data, null, 2)}`;
  }
  
  return output;
}

const logger = {
  info: (message, data) => console.log(formatMessage('INFO', message, data)),
  warn: (message, data) => console.warn(formatMessage('WARN', message, data)),
  error: (message, data) => console.error(formatMessage('ERROR', message, data)),
  success: (message, data) => console.log(formatMessage('SUCCESS', message, data)),
  debug: (message, data) => {
    if (process.env.NODE_ENV === 'development') {
      console.log(formatMessage('DEBUG', message, data));
    }
  },
};

module.exports = logger;
