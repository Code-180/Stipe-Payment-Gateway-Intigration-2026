/**
 * In-Memory Payment Store
 * 
 * Simulates a database for demo purposes. In production, replace with
 * a real database (PostgreSQL, MongoDB, etc.). Stores payment records
 * with metadata, status tracking, and refund history.
 */

const logger = require('./logger');

/** @type {Map<string, Object>} */
const payments = new Map();

const store = {
  /**
   * Add a new payment record
   * @param {string} id - Stripe Payment Intent ID
   * @param {Object} data - Payment data
   */
  add(id, data) {
    const record = {
      id,
      stripePaymentIntentId: id,
      amount: data.amount,
      currency: data.currency || 'usd',
      description: data.description || '',
      status: data.status || 'pending',
      customerEmail: data.customerEmail || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      refunds: [],
      totalRefunded: 0,
      metadata: data.metadata || {},
    };
    
    payments.set(id, record);
    logger.debug(`Payment stored: ${id}`);
    return record;
  },

  /**
   * Get a payment record by ID
   * @param {string} id - Payment Intent ID
   * @returns {Object|null}
   */
  get(id) {
    return payments.get(id) || null;
  },

  /**
   * Get all payments with optional filtering and pagination
   * @param {Object} options - Query options
   * @returns {{ payments: Object[], total: number, page: number, totalPages: number }}
   */
  getAll({ page = 1, limit = 10, status = '' } = {}) {
    let allPayments = Array.from(payments.values());
    
    // Sort by creation date (newest first)
    allPayments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Filter by status if provided
    if (status) {
      allPayments = allPayments.filter(p => p.status === status);
    }
    
    const total = allPayments.length;
    const totalPages = Math.ceil(total / limit);
    const startIndex = (page - 1) * limit;
    const paginatedPayments = allPayments.slice(startIndex, startIndex + limit);
    
    return {
      payments: paginatedPayments,
      total,
      page,
      totalPages,
    };
  },

  /**
   * Update a payment record
   * @param {string} id - Payment Intent ID
   * @param {Object} updates - Fields to update
   * @returns {Object|null}
   */
  update(id, updates) {
    const existing = payments.get(id);
    if (!existing) {
      logger.warn(`Payment not found for update: ${id}`);
      return null;
    }
    
    const updated = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    payments.set(id, updated);
    logger.debug(`Payment updated: ${id}`, { status: updated.status });
    return updated;
  },

  /**
   * Add a refund record to a payment
   * @param {string} id - Payment Intent ID
   * @param {Object} refund - Refund data
   * @returns {Object|null}
   */
  addRefund(id, refund) {
    const existing = payments.get(id);
    if (!existing) return null;
    
    existing.refunds.push({
      refundId: refund.id,
      amount: refund.amount,
      status: refund.status,
      createdAt: new Date().toISOString(),
    });
    
    existing.totalRefunded += refund.amount;
    existing.updatedAt = new Date().toISOString();
    
    // Update status based on refund amount
    if (existing.totalRefunded >= existing.amount) {
      existing.status = 'refunded';
    } else {
      existing.status = 'partially_refunded';
    }
    
    payments.set(id, existing);
    logger.debug(`Refund added to payment: ${id}`, { refundAmount: refund.amount });
    return existing;
  },

  /**
   * Get summary statistics
   * @returns {Object}
   */
  getStats() {
    const all = Array.from(payments.values());
    const succeeded = all.filter(p => p.status === 'succeeded');
    const totalAmount = succeeded.reduce((sum, p) => sum + p.amount, 0);
    const totalRefunded = all.reduce((sum, p) => sum + p.totalRefunded, 0);
    
    return {
      totalPayments: all.length,
      successfulPayments: succeeded.length,
      failedPayments: all.filter(p => p.status === 'failed').length,
      pendingPayments: all.filter(p => ['pending', 'requires_payment_method', 'requires_confirmation', 'requires_action', 'processing', 'expired'].includes(p.status)).length,
      totalAmount,
      totalRefunded,
      successRate: all.length > 0 ? ((succeeded.length / all.length) * 100).toFixed(1) : '0.0',
    };
  },

  /** Clear all records (for testing) */
  clear() {
    payments.clear();
    logger.info('Payment store cleared');
  },
};

module.exports = store;
